#!/bin/bash

# Test script for the Observer Pattern Notification System
echo "=== Testing Observer Pattern Notification System ==="
echo ""

# Test 1: Create a test notification
echo "1. Creating a test notification..."
curl -X POST "http://localhost:8080/api/notifications/test" \
  -H "Content-Type: application/x-www-form-urlencoded" \
  -d "userEmail=customer@example.com&title=Test Notification&message=This is a test notification to demonstrate the Observer pattern&type=SYSTEM&priority=MEDIUM"

echo ""
echo ""

# Test 2: Get notifications for a user
echo "2. Getting notifications for customer@example.com..."
curl -X GET "http://localhost:8080/api/notifications/user/customer@example.com"

echo ""
echo ""

# Test 3: Get unread notification count
echo "3. Getting unread notification count..."
curl -X GET "http://localhost:8080/api/notifications/user/customer@example.com/count"

echo ""
echo ""

# Test 4: Create an appointment notification (this would trigger the Observer pattern)
echo "4. Testing appointment notification creation..."
echo "Note: This would normally be triggered when creating an appointment through the AppointmentService"
echo "The Observer pattern will automatically:"
echo "  - Log the notification (LoggingNotificationObserver)"
echo "  - Send email for high-priority notifications (EmailNotificationObserver)"
echo "  - Send WebSocket message for real-time updates (WebSocketNotificationObserver)"

echo ""
echo "=== Observer Pattern Benefits Demonstrated ==="
echo "✅ Loose Coupling: Services don't need to know about specific notification implementations"
echo "✅ Extensibility: Easy to add new notification types (SMS, Push, etc.)"
echo "✅ Single Responsibility: Each observer handles one type of notification"
echo "✅ Open/Closed Principle: Can add new observers without modifying existing code"
echo "✅ Real-time Updates: WebSocket integration for instant notifications"
echo "✅ Multiple Channels: Email, WebSocket, and Logging all work simultaneously"

echo ""
echo "=== How to Test ==="
echo "1. Start the application: mvn spring-boot:run"
echo "2. Create an appointment through the UI"
echo "3. Check the console logs for observer notifications"
echo "4. Check the customer dashboard for real-time notifications"
echo "5. High-priority notifications will trigger email logs"

